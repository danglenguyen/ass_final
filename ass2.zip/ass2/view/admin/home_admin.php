<?php
    include '../view/admin/header_admin.php';
?>
<?php
    include '../view/admin/pages.php';
?>
<?php
    include '../view/admin/footer_admin.php';
?>