<?php
include '../view/web/header_chitiet.php';
?>
<!--contact-->
<div class="contact">
	<div class="container">
		<h3>Contat</h3>
	 <div class="contact-top">
		<div class="col-md-6 contact-top1">
		  <h4 > Info</h4>
          <p class="text-contact">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took.</p>
		  <div class="contact-address">
		  	<div class="col-md-6 contact-address1">
			  	 <h5>Address</h5>
	             <p><b>The Company Name</b></p>
	             <p>25478 charms of pleasur</p>
	             <p>On the other hand, we denounce</p>	
		  	</div>
		  	<div class="col-md-6 contact-address1">
			  	  <h5>Email Address </h5>
	             <p>General :<a href="malito:mail@demolink.org"> info(at)Lorem.com</a></p>
	             <p>Office :<a href="malito:mail@demolink.org"> info(at)Lorem.com</a></p>
		  	</div>
		  	<div class="clearfix"></div>
		  </div>
		  <div class="contact-address">
		  	<div class="col-md-6 contact-address1">
			  	 <h5 >Phone </h5>
	             <p>Landline : 254-8974-5847</p>
	             <p>Mobile : +174 1478 74755</p>
	        </div>
		  	<div class="clearfix"></div>
		  </div>
		</div>
		<div class="col-md-6 contact-right">
	
            <form>
               <input type="text"  placeholder="Name" required="">
			   <input type="text" placeholder="Email" required="">
			   <input type="text" placeholder="Subject" required="">
			   <textarea  placeholder="Message" requried=""></textarea>
			   <label class="hvr-sweep-to-right">
	           <input type="submit" value="Submit">
	           </label>
			</form>
		</div>
		<div class="clearfix"> </div>
</div>
	</div>
	
</div>
<!--//contact-->

<?php
include '../view/web/footer.php';
?>