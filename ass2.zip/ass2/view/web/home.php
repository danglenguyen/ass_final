<?php
include '../view/web/header.php';
?>
<div class="content">
<?php
include '../view/web/phan3.php';
?>
</div>
<?php
include '../view/web/footer.php';
?>